package com.example.customer.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.customer.feign.CustomerFeign;
import com.example.customer.model.Customer;
import com.example.customer.service.CustomerService;


@RestController
@RequestMapping("/cust")
public class CustomerController {
@Autowired
private CustomerService customerservice;
@Autowired
private CustomerFeign cf;

@GetMapping("/product") 
public ResponseEntity<?>getAll()
{ 
return cf.getProducts();
}

@GetMapping("pro/product/{id}")
public ResponseEntity<?>getByid(@PathVariable String id)
{
	return customerservice.getevent(id);
}


@GetMapping("/customer/{id}")
public Customer getproduct(@PathVariable String id) {
	
	Customer customer= customerservice.findCustomertByCode(id);	
			
	return customer;
}
@GetMapping("/customers")
public List<Customer> getAllcustomer() {
	
List <Customer> c= customerservice.getAll();	
			
	return c; 
}
@PostMapping("/customer")
public Customer createcustomer(@RequestBody Customer customer) {
	
	customerservice.addCustomer(customer);
			
	return customer;		
	
}
@DeleteMapping("/customer/{id}")
public void deleteCustomer(@PathVariable String id) {
	
	customerservice.deleteCustomer(id);
	
}
@PutMapping("/product/{id}") 
public Customer updateCustomer(@RequestBody Customer customer ) {
	
	customerservice.updatecustomer(customer) ;
			
	return customer;
}



}

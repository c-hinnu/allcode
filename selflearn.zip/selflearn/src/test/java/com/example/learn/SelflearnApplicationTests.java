package com.example.learn;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SelflearnApplicationTests {

	@Test
	void contextLoads() {
	}

}
